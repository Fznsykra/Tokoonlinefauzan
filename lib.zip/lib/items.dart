var items = [
["Celana","./lib/assets/Celana.png","Rp.60000","ready stok dan real pict bahan ngaret dan lentur nyaman dipakai"],
["Dress","./lib/assets/Dress.png","Rp.50000","Dress flanel wanita masa kini dengan kualitas premium Bisa dipakai untuk pria dan wanita Jadi buat kalian yang bingung mencari outfit buat semua acara kami solusinya dan juga bisa dipakai kemana saja "],
["Kameja","./lib/assets/Kameja.png","Rp.80000","Kemeja flanel pria masa kini dengan kualitas premium Bisa dipakai untuk pria dan wanita Jadi buat kalian yang bingung mencari outfit buat semua acara kami solusinya"],
["Kaos","./lib/assets/Kaos.png","Rp.40000","Kemeja flanel pria masa kini dengan kualitas premium Bisa dipakai untuk pria dan wanita Jadi buat kalian yang bingung mencari outfit buat semua acara kami solusinya"],
["Sepatu","./lib/assets/Sepatu.png","Rp.120000","Kemeja flanel pria masa kini dengan kualitas premium Bisa dipakai untuk pria dan wanita Jadi buat kalian yang bingung mencari outfit buat semua acara kami solusinya"],
["Topi","./lib/assets/Topi.png","Rp.35000","Kemeja flanel pria masa kini dengan kualitas premium Bisa dipakai untuk pria dan wanita Jadi buat kalian yang bingung mencari outfit buat semua acara kami solusinya"]

];