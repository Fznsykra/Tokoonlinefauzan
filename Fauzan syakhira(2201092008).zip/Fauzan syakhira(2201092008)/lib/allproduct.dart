import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Allproduct extends StatefulWidget {
  const Allproduct({super.key});

  @override
  State<Allproduct> createState() => _AllproductState();
}

class _AllproductState extends State<Allproduct> {

  List productList = [];

  Future<void>getAllProduct() async{

    String urlProduct = "https://ambiguous-observers.000webhostapp.com/getallproduct.php";

  try{
  var response = await http.get(Uri.parse(urlProduct));
  productList = jsonDecode(response.body);
  setState(() {
    productList = jsonDecode(response.body);
  });
  }catch(exc){
print(exc);
}

  }
@override
void initState(){
  setState(() {
    getAllProduct();
  });
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
  appBar: AppBar(
          title: Text(
        "Product List",
        style: TextStyle(
            color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
      ),backgroundColor: Colors.green ),
      body: ListView.builder(
        itemCount: productList.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(5),
            child: ListTile(
              leading: Icon(
                CupertinoIcons.ant_circle_fill,
                color: Colors.red,
                size: 20,
              ),
              title: Text(
                productList[index]["name"],
                style: const TextStyle(
                    color: Colors.green,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                productList[index]["description"],
                style: const TextStyle(
                    color: Colors.black54,
                    fontSize: 13,
                    fontWeight: FontWeight.normal),
              ),
            ),
          );
        },
      ),
    );
  }
}