-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 24, 2024 at 05:45 AM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21739558_project_2a`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `promo` double NOT NULL,
  `description` varchar(300) NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `nama`, `price`, `promo`, `description`, `image`) VALUES
(1, 'LENOVO Legion Y520-15IKBN - Black', 15817500, 0, 'Lenovo Legion Y520 memudahkan Anda untuk memasuki arena Gaming dari mana saja karena memiliki bobot yang ringan, bodi tipis, dan kinerja Gaming super mulus.', 'https://assets.bmdstatic.com/web/image?model=product.template&field=image_1024&id=10015&unique=4187359'),
(2, 'LENOVO IdeaPad IP330-15ICH', 12556500, 0, 'Lenovo IdeaPad 330 adalah laptop ideal untuk kebutuhan sehari-hari. Laptop ini bukan hanya sekedar untuk menemani aktivitas namun untuk investasi.', 'https://assets.bmdstatic.com/web/image?model=product.product&field=image_1024&id=13381&unique=59c8040'),
(3, 'MSI Notebook Creator 17 A10SFS', 51463000, 0, 'MSI Creator 17 merupakan laptop bertenaga yang sangat cocok untuk kebutuhan pekerjaan yang membutuhkan kreativitas. Laptop dari MSI ini tepat sekali untuk para pembuat konten, produser musik atau pun desainer yang ingin meningkatkan efisiensi bekerja atau pun meningkatkan produktivitas.', 'https://assets.bmdstatic.com/web/image?model=product.product&field=image_1024&id=55128&unique=61e1ab9'),
(4, 'ACER Predator Triton 500 PT515-51-713V (Core i7-9750H, 16GB, 512GB SSD, RTX 2060)', 36326500, 0, 'Acer Predator Triton 500 punya desain inovatif dan spesifikasi tinggi. Dimensi laptop yang ringkas ini membuat Predator Triton 500 mudah dimasukan ke dalam tas ransel. Predator Triton 500 punya berat kurang lebih 2.1 kg dan tebal hanya 17.9 mm. ', 'https://assets.bmdstatic.com/web/image?model=product.template&field=image_1024&id=16256&unique=f2e9532'),
(5, 'LENOVO Yoga Slim 7 14ITL05', 19979000, 0, 'Lenovo Yoga Slim 7 adalah laptop slim yang menggabungkan kekuatan Intel Core generasi ke-11 dan daya tahan baterai hingga 14 jam. Layar Full HD yang dioptimalkan dengan Dolby Vision dan suara 3D Dolby Atmos membuatnya sempurna untuk menikmati hiburan multimedia.', 'https://assets.bmdstatic.com/web/image?model=product.product&field=image_1024&id=57984&unique=bfff669'),
(6, 'DELL Inspiron 3501 (Core i3-1115G4, 4GB, 256GB SSD)', 8173000, 0, 'Dell Inspiron 3501 adalah laptop ringan dengan performa kencang. Laptop ini ditenagai prosesor Intel Core i3 generasi ke-11. Prosesor Dual Core ini memiliki kecepatan clock hingga 4.1 GHz dengan 6MB Smart Cache. Laptop ini juga didukung RAM 4GB dan storage SSD yang responsif.', 'https://assets.bmdstatic.com/web/image?model=product.product&field=image_1024&id=58050&unique=328c041'),
(7, 'DELL Alienware m15 (R7 5800H, 16GB, 512GB)', 43400000, 0, 'Alienware m15 R7 adalah laptop gaming terbaru dari Dell yang dibekali layar dengan kecepatan refresh rate tinggi. Laptop ini memiliki layar 15.6 inci dengan resolusi FHD. Kecepatan refresh tinggi dan waktu respon singkat nyaman untuk gaming mulus. Ditambah lagi, ', 'https://assets.bmdstatic.com/web/image?model=product.template&field=image_1024&id=49301&unique=a3ff6d1'),
(8, 'ASUS ROG Strix G G713IC-R735B6T-O (AMD Ryzen 7 4800H, 8GB, 512GB SSD, RTX 3050)', 18160000, 0, 'Asus ROG Strix G17 adalah laptop gaming 17 inci dengan performa serius. Laptop ini ditenagai CPU AMD Ryzen 7 4000 Series terbaru dan grafis diskrit NVIDIA RTX 3050. Laptop ini mampu memainkan game AAA di FPS tinggi. ', 'https://assets.bmdstatic.com/web/image?model=product.product&field=image_1024&id=62719&unique=6a92f7d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
