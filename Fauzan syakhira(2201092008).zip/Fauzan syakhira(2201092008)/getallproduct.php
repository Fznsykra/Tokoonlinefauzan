<?php
include 'dbconnect.php';

$query = "SELECT name, price, promo, description, images
    FROM product";

$execute = mysqli_query($conn,$query);
$arrproduct = [];
while($rows = mysqli_fetch_array($execute)){
  $arrproduct[] = $rows;

}
print(json_encode($arrproduct));

?>

