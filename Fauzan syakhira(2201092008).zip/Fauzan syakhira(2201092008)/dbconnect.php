<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'id21739588_project_2a');
define('DB_PASS', '!234Asdf');
define('DB_NAME', 'id21739588_project_2a');

$conn = new mysqli (DB_HOST, DB_USER, DB_PASS, DB_NAME);
if(mysqli_connect_errno()){
    echo "Failed to connect:" .mysqli_connect_error();
    die();
}
?>